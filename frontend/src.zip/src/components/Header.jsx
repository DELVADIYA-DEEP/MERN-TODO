import React from 'react';
import { useNavigate } from 'react-router-dom';
import { logout } from '../api/todoApi';

const Header = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        logout(); // Clear the token from local storage
        navigate('/login'); // Redirect to the login page
    };

    return (
        <header>
            <h1>To-Do App</h1>
            <button onClick={handleLogout}>Logout</button>
        </header>
    );
};

export default Header;
