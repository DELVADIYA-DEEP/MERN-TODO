import React, { useState, useEffect } from 'react';
import { getTodos, createTodo, updateTodo, deleteTodo } from '../api/todoApi';
import TodoForm from '../components/TodoForm.jsx';
import TodoList from '../components/TodoList.jsx';
import Header from '../components/Header.jsx';

const HomePage = () => {
    const [todos, setTodos] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Fetch todos from the backend on component load
    useEffect(() => {
        fetchTodos();
    }, []);

    const fetchTodos = async () => {
        setLoading(true);
        try {
            const data = await getTodos();
            setTodos(data);
        } catch (err) {
            setError('Failed to fetch todos.');
        } finally {
            setLoading(false);
        }
    };

    const handleAddTodo = async (task) => {
        try {
            const newTodo = await createTodo({ task });
            setTodos([...todos, newTodo]);
        } catch (err) {
            setError('Failed to add todo.');
        }
    };

    const handleDeleteTodo = async (id) => {
        try {
            await deleteTodo(id);
            setTodos(todos.filter(todo => todo._id !== id));
        } catch (err) {
            setError('Failed to delete todo.');
        }
    };

    const handleToggleTodo = async (id, completed) => {
        try {
            const updatedTodo = await updateTodo(id, { completed });
            setTodos(todos.map(todo => (todo._id === id ? updatedTodo : todo)));
        } catch (err) {
            setError('Failed to update todo.');
        }
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div>
            <Header />
            <h2>My To-Do List</h2>
            <TodoForm onAdd={handleAddTodo} />
            <TodoList
                todos={todos}
                onDelete={handleDeleteTodo}
                onToggle={handleToggleTodo}
            />
        </div>
    );
};

export default HomePage;
